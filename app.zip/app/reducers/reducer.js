import { 
  SELECTBOX_OPTION,
  REACT_REPOSITORY,
  REDUX_REPOSITORY,
  REACT_DOM_REPOSITORY,
  LODASH_REPOSITORY,
  RAMDA_REPOSITORY
} from "app_actions/action.js";

const initialState = {
  selectedValue: [],
  gitRepo_Results: []
};

export default function reducer(state = initialState, action) {
  switch (action.type) {

    case SELECTBOX_OPTION: {
      return {
        ...state,
        selectedValue: action.payload
      }
    }
    case REACT_REPOSITORY: {
      return {
        ...state,
        gitRepo_Results: action.payload
      }
    }
    case REDUX_REPOSITORY: {
      return {
        ...state,
        gitRepo_Results: action.payload
      }
    }
    case REACT_DOM_REPOSITORY: {
      return {
        ...state,
        gitRepo_Results: action.payload
      }
    }
    case LODASH_REPOSITORY: {
      return {
        ...state,
        gitRepo_Results: action.payload
      }
    }
    case RAMDA_REPOSITORY: {
      return {
        ...state,
        gitRepo_Results: action.payload
      }
    }
    default: {
      return state;
    }
  }
}
