import React from 'react';
import { connect } from "react-redux";
import { ENDPOINTS } from "app_constants/ENDPOINTS.js";
import SelectComponent from "app_components/SelectComponent.jsx";
import TableComponent from "app_components/TableComponent.jsx";

class Home extends React.Component {
    constructor(props){
        super(props);
        this.state = {
          selectBoxData: []
        }
    }

    componentWillMount() {
        let selectData = [];
        Object.keys(ENDPOINTS).forEach(function(key) {
          selectData.push({
            label: ENDPOINTS[key].label,
            value: ENDPOINTS[key].value
          });
        });
        this.state.selectBoxData = selectData;
    }

    render() {
      return (
        <div>
            <SelectComponent selectData={this.state.selectBoxData} />
            <TableComponent />
        </div>
      );
    }
}
export default connect()(Home);
