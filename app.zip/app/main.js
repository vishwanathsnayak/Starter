import React from 'react';
import { render } from 'react-dom';
import { Router, Route, hashHistory } from 'react-router';
import { Provider } from 'react-redux';

//  import store
import store from './store';

const rootElement = document.getElementById('root');

//  import components
import Home from 'container_source/Home.jsx';

render(
  <Provider store={store}>
    <Router history={hashHistory}>
      <Route path="/" component={Home} />
    </Router>
  </Provider>,
  rootElement
);
