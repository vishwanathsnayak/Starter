import React from "react";
import { connect } from "react-redux";
import PropTypes from 'prop-types';
import {
    TableHead,
    TableCell,
    TableRow,
    TableSortLabel,
    Tooltip
  } from '@material-ui/core/';

  const rows = [
    { id: 'reponame', numeric: false, disablePadding: true, label: 'Repo Name' },
    { id: 'stars', numeric: true, disablePadding: false, label: 'Number of Stars' },
    { id: 'forks', numeric: true, disablePadding: false, label: 'Number of Forks' },
 ];

class TableHeaderSorting extends React.Component {
    createSortHandler = property => event => {
      this.props.onRequestSort(event, property);
    };
  
    render() {
      const { order, orderByCol } = this.props;
      return (
        <TableHead>
          <TableRow>
            {rows.map(row => {
              return (
                <TableCell
                  key={row.id}
                  numeric={row.numeric}
                  padding={row.disablePadding ? 'none' : 'default'}
                  sortDirection={orderByCol === row.id ? order : false}
                >
                  <Tooltip
                    title="Sort"
                    placement={row.numeric ? 'bottom-end' : 'bottom-start'}
                    enterDelay={300}
                  >
                    <TableSortLabel
                      active={orderByCol === row.id}
                      direction={order}
                      onClick={this.createSortHandler(row.id)}
                    >
                      {row.label}
                    </TableSortLabel>
                  </Tooltip>
                </TableCell>
              );
            }, this)}
          </TableRow>
        </TableHead>
      );
    }
  }
  
  TableHeaderSorting.propTypes = {
    onRequestSort: PropTypes.func.isRequired,
    order: PropTypes.string.isRequired,
    orderByCol: PropTypes.string.isRequired
  };

  export default connect()(TableHeaderSorting);