import React from "react";
import { connect } from "react-redux";
import { Select, MenuItem, Input, InputLabel, FormControl } from "@material-ui/core/";
import { selectBoxOptions } from "app_actions/action.js";
import PropTypes from 'prop-types';

class SelectComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          selectedVal: "",
        };
        this.handleChangeDivision = this.handleChangeDivision.bind(this);
    }
    renderDivisionOptions() {
        return this.props.selectData.map((dt, i) => {
          return (
            <MenuItem key={i} value={dt.value}>
              {dt.label}
            </MenuItem>
          );
        });
    }
    
    handleChangeDivision(event) {
        let data = {};
        data = event.target.value;
        this.setState({ selectedVal: data });
        this.props.dispatch(selectBoxOptions(data));
    }

    render() {
        return (
            <FormControl>
                <InputLabel htmlFor="selectRepoId">Select Repo</InputLabel>
                <Select
                    value={this.state.selectedVal}
                    onChange={this.handleChangeDivision.bind(this)}
                    input={<Input id="selectRepoId" />}
                    >
                    {this.renderDivisionOptions()}
                </Select>
            </FormControl>  
        )
    }
}

SelectComponent.propTypes = {
    selectData: PropTypes.array.isRequired
};

export default connect()(SelectComponent);

