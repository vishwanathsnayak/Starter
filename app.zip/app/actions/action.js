import axios from "axios";
export const SELECTBOX_OPTION = "SELECTBOX_OPTION";
export const REACT_REPOSITORY = "REACT_REPOSITORY";
export const REACT_REPOSITORY_ERROR = "REACT_REPOSITORY_ERROR";
export const REDUX_REPOSITORY = "REDUX_REPOSITORY";
export const REDUX_REPOSITORY_ERROR = "REDUX_REPOSITORY_ERROR";
export const REACT_DOM_REPOSITORY = "REACT_DOM_REPOSITORY";
export const REACT_DOM_REPOSITORY_ERROR = "REACT_DOM_REPOSITORY_ERROR";
export const LODASH_REPOSITORY = "LODASH_REPOSITORY";
export const LODASH_REPOSITORY_ERROR = "LODASH_REPOSITORY_ERROR";
export const RAMDA_REPOSITORY = "RAMDA_REPOSITORY";
export const RAMDA_REPOSITORY_ERROR = "RAMDA_REPOSITORY_ERROR";

export function getGithubRepoDetails(api, typeDataSucess, typeDataError) {
  let dataItem = [];
  return (dispatch) => { 
      axios.get(api).then(response => {
        const type = response.status === 200 ? typeDataSucess : typeDataError;
        response.data.items.map(function(item){
          dataItem.push({
            name: item.name,
            starCount: item.stargazers_count,
            forksCount: item.forks_count
          });
        })
        dispatch({
          type,
          payload: dataItem || []
        })
      })
      .catch(error => {
        dispatch({
          type,
          payload: []
        })
        console.log('Error fetching and parsing data', error);
      });
  }
}

export function selectBoxOptions(data) {
  let actionTypeSucess = "",
      actionTypeError = "",
      splitStr = "";
      splitStr = data.split("=")[1];
      if(splitStr && splitStr === "react") {
        actionTypeSucess = REACT_REPOSITORY;
        actionTypeError = REACT_REPOSITORY_ERROR;
      }
      else if(splitStr && splitStr === "redux") {
        actionTypeSucess = REDUX_REPOSITORY;
        actionTypeError = REDUX_REPOSITORY_ERROR;
      }
      else if(splitStr && splitStr === "react-dom") {
        actionTypeSucess = REACT_DOM_REPOSITORY;
        actionTypeError = REACT_DOM_REPOSITORY_ERROR;
      }
      else if(splitStr && splitStr === "lodash") {
        actionTypeSucess = LODASH_REPOSITORY;
        actionTypeError = LODASH_REPOSITORY_ERROR;
      }
      else if(splitStr && splitStr === "ramda") {
        actionTypeSucess = RAMDA_REPOSITORY;
        actionTypeError = RAMDA_REPOSITORY_ERROR;
      }
      return (dispatch) => {
        dispatch({
          type: SELECTBOX_OPTION,
          payload: splitStr
        });
       dispatch(getGithubRepoDetails(data, actionTypeSucess, actionTypeError));
      }
}


